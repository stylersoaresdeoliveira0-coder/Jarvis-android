# JARVIS 8.2 — comandos de voz

Diga **“Hey Jarvis”**, espere o JARVIS responder “Olá, senhor. Estou ouvindo” e então diga o comando. Não fale o comando inteiro junto com a palavra de ativação: o reconhecimento do comando só começa depois da saudação. O detector incluído foi treinado para “Hey Jarvis”; a palavra isolada “Jarvis” não é garantida. Após uma resposta, há uma janela de aproximadamente 12 segundos para continuar a conversa sem repetir o chamado.

## Conversar com a IA local
- “Explique a gravidade de um jeito simples.”
- “Quem foi Santos Dumont?”
- “Me ajuda a organizar meus estudos.”
- “Qual a diferença entre marketing e publicidade?”
- Depois da saudação: “Instale o cérebro local.”
- Quando ele pedir autorização: “Confirmo o download.”
- “Cancele o download.”

O primeiro download tem cerca de 614 MB e é solicitado por voz. O modelo local responde perguntas gerais, mas é pequeno e pode errar. Para fatos específicos, ele pode consultar a Wikipédia em português.

## Sistema e aplicativos
- “Abra o YouTube / WhatsApp / Instagram / Spotify / Chrome.”
- “Ligue a lanterna.” / “Desligue a lanterna.”
- “Volume em 40 por cento.” / “Aumente o volume.”
- “Brilho em 60 por cento.” (pode exigir permissão especial nas configurações)
- “Crie um alarme para 06:30.”
- “Temporizador de 5 minutos.”
- “Pause a música.” / “Retome a música.”
- “Quanto de bateria temos?”
- “Que horas são?” / “Que dia é hoje?”
- “Navegue para o Shopping...”
- “Pesquise na internet ...”

## Localização e clima
- “Vai chover hoje?”
- “Como fica o tempo amanhã?”

O JARVIS usa a localização atual apenas quando a consulta é solicitada. É necessário permitir localização e manter a localização do telefone ligada.

## Contatos e mensagens
- “Cadastre contato Ana telefone 75999999999.”
- “Mande WhatsApp para Ana dizendo estou chegando.”

O WhatsApp abre com o texto preenchido. O toque final em Enviar permanece no WhatsApp.

## Privacidade e uso
- Detecção “Hey Jarvis” local.
- Cérebro Qwen3 local após download.
- Consulta de clima e enciclopédia usa internet.
- Reconhecimento de fala PT-BR pode usar a rede se não houver pacote offline disponível.
- O serviço de microfone exibe uma notificação permanente e consome bateria.
