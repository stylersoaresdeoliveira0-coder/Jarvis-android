# J.A.R.V.I.S. Android 8.2 — assistente de voz local

Projeto Android nativo para o Galaxy A16 5G e outros aparelhos Android 8.0+. A interface é um HUD vertical inspirado em ficção científica. O uso normal é por voz: não há campo para digitar comandos.

## O que faz
- Detector local de palavra-chave **“Hey Jarvis”** com openWakeWord.
- Serviço Android de microfone em primeiro plano, com notificação persistente e tentativa de manter o detector ativo com a tela apagada.
- Reconhecimento de cada comando em português com `SpeechRecognizer`; tenta o mecanismo on-device primeiro quando o Android o oferece.
- Resposta falada via TextToSpeech PT-BR e animação de onda/reator durante escuta e fala.
- Janela de conversa de seguimento por 12 segundos após uma resposta.
- Comandos nativos permitidos: abrir uma lista de aplicativos, lanterna, volume, brilho (quando autorizado), alarmes, temporizadores, bateria, data/hora, mídia, mapas, pesquisa e preparação de mensagens.
- Previsão do tempo pela localização atual quando perguntado; as coordenadas são usadas na consulta ao Open-Meteo, não ficam gravadas pelo JARVIS.
- Memória pessoal local e lista de contatos guardadas no armazenamento privado do app.
- Cérebro generativo Qwen3-0.6B local via LiteRT-LM. Ferramentas de consulta meteorológica e de enciclopédia em português podem ser chamadas pelo modelo.

## Cérebro de IA local
- Modelo: `litert-community/Qwen3-0.6B`, artefato `Qwen3-0.6B.litertlm` (Apache-2.0).
- Tamanho: 613.722.264 bytes, aproximadamente 586 MiB / 614 MB.
- Runtime: LiteRT-LM Android 0.18.0; backend CPU por compatibilidade.
- O modelo não está dentro do APK. Depois de instalar, diga **“Hey Jarvis”**, espere a saudação, diga **“instale o cérebro local”** e, quando ele pedir, responda **“confirmo o download”**. Ele explica o download e pede confirmação falada. Recomenda-se Wi-Fi e 2 GB livres.
- O arquivo é baixado por HTTPS do Hugging Face, conferido por tamanho e SHA-256 e salvo no armazenamento privado do aplicativo.
- Depois do primeiro download, a geração de respostas é local, sem custo por pergunta e sem enviar o texto da conversa a um provedor de IA. Este projeto não usa a API do ChatGPT nem tem acesso à sua conta ChatGPT; a inteligência embutida é o Qwen3 local. As consultas ao clima e à enciclopédia usam internet quando solicitadas.

### Limitações de qualidade
Qwen3-0.6B é um modelo pequeno, executado no processador do celular. É gratuito e privado depois do download, mas é muito menos capaz que ChatGPT/Gemini de grande porte; pode demorar, errar, simplificar demais ou não entender perguntas complexas. O pacote oferece chamadas de ferramentas, mas um modelo de 0,6 bilhão de parâmetros pode escolher uma ferramenta incorretamente ou não escolhê-la em algumas perguntas. A voz usada para falar depende do mecanismo e do pacote de voz PT-BR instalado no Android. A Wikipédia serve como apoio factual, não como busca de notícias em tempo real. O clima vem do Open-Meteo.

## Palavra de ativação e tela apagada
- O modelo incluído detecta **“Hey Jarvis”**, não garante a palavra isolada “Jarvis”. Diga a palavra-chave, espere a saudação e só então fale o comando; o reconhecimento do comando começa depois da resposta falada.
- A detecção da palavra-chave é local. A transcrição do comando pode usar serviço remoto se não houver reconhecimento PT-BR offline instalado no telefone.
- O serviço deve ser iniciado enquanto o JARVIS estiver aberto e visível. Ele exibe notificação permanente. O Android/Samsung pode encerrar ou limitar o serviço, especialmente em economia de bateria. A operação com tela apagada é melhor esforço, não uma garantia de funcionamento ininterrupto.
- Após reiniciar o telefone, abra o JARVIS uma vez para iniciar a escuta novamente.

## Ações e segurança
- As ferramentas da IA são uma lista permitida e só devem ser chamadas quando o pedido falado pedir claramente a ação.
- WhatsApp é aberto com a mensagem preparada; o usuário ainda precisa tocar em **Enviar** no próprio WhatsApp. Não há envio invisível de DM.
- Algumas telas do Android não podem ser abertas diretamente quando o app está em segundo plano; nesses casos, o JARVIS prepara uma notificação.
- O app não obtém acesso irrestrito ao Android, não executa shell/código arbitrário e não tem “livre-arbítrio” do aparelho.

## Compilar APK pelo próprio Galaxy (GitHub Actions)
1. Crie um repositório público vazio chamado `jarvis-android` no GitHub.
2. Envie `JARVIS-ANDROID-8.2-SOURCE.zip` para a raiz do repositório.
3. Crie um arquivo `.github/workflows/build-apk.yml` e cole o conteúdo de `build-apk.yml` incluído no kit.
4. Faça Commit. O workflow inicia automaticamente; também pode ser iniciado em Actions → Build JARVIS Android APK → Run workflow.
5. Ao terminar, baixe o artefato `JARVIS-Android-8.2-debug-APK`, extraia e instale `app-debug.apk`.

O APK é debug e não é uma publicação assinada da Play Store. O usuário precisa autorizar a instalação do APK na fonte usada para abri-lo.

## Estado de validação
Foram realizadas inspeções estáticas de código e estrutura, verificação XML/HTML/JS/YAML, revisão dos pontos de integração LiteRT-LM, hash/tamanho do modelo e integridade dos pacotes ZIP. **Não foi possível compilar nem testar fisicamente no Galaxy A16 neste ambiente**, porque não há Android SDK/Gradle instalado. O GitHub Actions precisa realizar o primeiro build real.

## Componentes de terceiros
- LiteRT-LM Android 0.18.0 — Apache-2.0.
- Qwen3-0.6B LiteRT-LM — Apache-2.0.
- openwakeword-android 0.1.0 — consulte a licença no projeto de origem e `THIRD-PARTY-NOTICES.txt`.
- Open-Meteo — termos da API e atribuição conforme serviço.
